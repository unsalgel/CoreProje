# 404 Page - svg animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/namratapdr/pen/yLOgREo](https://codepen.io/namratapdr/pen/yLOgREo).

This is my first time working with svg  animation so here's  a  404 page for this